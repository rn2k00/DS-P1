class Bocata < ApplicationRecord
end
