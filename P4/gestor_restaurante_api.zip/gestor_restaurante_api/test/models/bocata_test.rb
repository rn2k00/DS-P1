require "test_helper"

class BocataTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
