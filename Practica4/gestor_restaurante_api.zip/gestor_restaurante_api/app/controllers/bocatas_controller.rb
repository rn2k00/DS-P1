class BocatasController < ApplicationController
  def index
    @bocatas = Bocata.all    
    logger.info "Cargando bocatas para usuario: #{params[:usuario]}, Total: #{@bocatas.count}"
    render json: @bocatas
  end

  def create
    @bocata = Bocata.new(bocata_params)
    if @bocata.save
      render json: @bocata, status: :created
    else
      render json: @bocata.errors, status: :unprocessable_entity
    end
  end

  def update
    @bocata = Bocata.find(params[:id])
    if @bocata.update(bocata_params)
      render json: @bocata
    else
      render json: @bocata.errors, status: :unprocessable_entity
    end
  end

  def destroy
    bocata = Bocata.find(params[:id])
    if bocata.destroy
       head :ok
    else
       render json: { error: "Failed to delete" }, status: :unprocessable_entity
    end
  end

  private

  def bocata_params
    params.require(:bocata).permit(:ing, :salsa, :pan, :tamanio, :nombre, :usuario, :gluten)
  end
end
