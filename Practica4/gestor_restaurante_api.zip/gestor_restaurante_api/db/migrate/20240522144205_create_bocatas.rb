class CreateBocatas < ActiveRecord::Migration[7.1]
  def change
    create_table :bocatas do |t|
      t.text :ing
      t.string :pan
      t.string :tamanio
      t.string :nombre
      t.string :usuario
      t.boolean :gluten

      t.timestamps
    end
  end
end
