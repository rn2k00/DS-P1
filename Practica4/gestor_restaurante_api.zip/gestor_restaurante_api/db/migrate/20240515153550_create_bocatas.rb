class CreateBocatas < ActiveRecord::Migration[7.1]
  def change
    create_table :bocatas do |t|
      t.text :ing, array: true, default: []
      t.string :pan
      t.string :tamanio
      t.string :nombre

      t.timestamps
    end
  end
end
