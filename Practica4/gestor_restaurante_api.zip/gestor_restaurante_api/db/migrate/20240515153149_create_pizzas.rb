class CreatePizzas < ActiveRecord::Migration[7.1]
  def change
    create_table :pizzas do |t|
      t.text :ing, array: true, default: []
      t.string :salsa
      t.string :tipoMasa
      t.string :tamanio
      t.string :nombre

      t.timestamps
    end
  end
end
