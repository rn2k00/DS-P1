class Pizza < ApplicationRecord
end
