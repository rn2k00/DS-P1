class CreatePizzas < ActiveRecord::Migration[7.1]
  def change
    create_table :pizzas do |t|
      t.string :ing
      t.string :salsa
      t.string :tipoMasa
      t.string :tamanio
      t.string :nombre
      t.string :usuario
      t.boolean :gluten

      t.timestamps
    end
  end
end
